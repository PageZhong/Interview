$(function(){
   //sliders
   var num=0;
   var index=1;
   var timer=null;
   function show(){
   	// clearInterval(timer);
   	var a1=$(".sliders");
   	    // if (num%6==0) {
   	    // 	a1.css({zIndex:1});
   	    // }
         //  a1.css({zIndex:0});
         // a1.eq(num%6).prev().css({zIndex:1,opacity:1});
   		a1.eq(num%6).css({zIndex:++index,opacity:0});
   		a1.eq(num%6).animate({opacity: 1}, 1000);
   };
   $(".slider").mouseover(
   	function (){
   		clearInterval(timer);
         $(this).css("cursor","pointer");
   	}).mouseout(
   		function(){
   			timer=setInterval(function(){
               num++;
               show();
            }, 2000);
   		}
   	);
   $(".rightbtn").click(function(event) {
      clearInterval(timer);
      num--;
      if (num<0) {
         num=5;         
      }
      show();
   });
   $(".leftbtn").click(function(event) {
      clearInterval(timer);
      num++;
      show();
   });
   timer=setInterval(function (){
      num++;
      show();
   }, 2000);
   // sliders
   $(".middle").mouseenter(function(){
      $(".code").css("display","block").stop().animate({opacity: 1}, "slow");
   }).mouseleave(function(event) {
      $(".code").stop().animate({opacity:0}, "slow",function(){$(".code").css("display","none")});
   });
   //a color
   $(".ascaterlogy:contains('原创作品')").css({color:"#ff0084"});
   $(".ascaterlogy:contains('活动')").css({color:"#fabe00"});
   $(".ascaterlogy:contains('设计文章')").css({color:"#a6ce38"});
   //select items
   var choose=$(".select ul")
   $(".select").mouseenter(function(){
      choose.css({display:"block"})
   }).mouseleave(function(){
      choose.css({display:"none"})
   })
   $(".choose").click(function(){
      $(".choose1").text($(this).text())
      choose.css({
         display: 'none'});
   })
   //close ads
   $(".closeicon").click(function (){
      $(".close").slideUp("slow");
   })
   //gotop
   $(document).scroll(function(event) {
      if ($(this).scrollTop()>1) {
         $(".gotop").css("display","block");
      }else{
         $(".gotop").css("display","none");
      }
   });
});
























