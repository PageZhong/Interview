$(function(){
   var num=0;
   var timer=null;
   function forwards(){
      var a1=$(".sli1").eq(num%4);
      if (num%4==0&&num!=0) {
         $(".sli1").eq(3).stop().animate({
            opacity: 0},
            "slow", function() {
            $(this).css({display:"none"})
         });
      }else{
         a1.prev().stop().animate({opacity:0}, "slow",function(){$(this).css("display","none")});
      }
   a1.css({display:"block",opacity:0}).stop().animate({opacity:1}, "slow");
      // a1.css({display:"block",opacity:0})
      // .animate({opacity:1}, "slow",function(){$(".sli1").not(a1).css({display:"none",opacity:0});});
   }
   function backwards(){
      var a1=$(".sli1").eq(num%4);
      if (num%4==3) {
         $(".sli1").eq(0).stop().animate({
            opacity: 0},
            "slow", function() {
            $(this).css({display:"none"})
         });
      }else{
         a1.next().stop().animate({opacity:0}, "slow",function(){$(this).css("display","none")});
      }
   a1.css({display:"block",opacity:0}).stop().animate({opacity:1}, "slow");
   }
   $(".buttonl").click(function(){
      clearInterval(timer);
      num++;
      forwards();
   })
   $(".buttonr").click(function(){
      clearInterval(timer);
      num--;
      if (num==-1) {
         num=3;
      }
      backwards();
   })
   $("#slider").mouseenter(function(event) {
      clearInterval(timer);
   }).mouseleave(function(event) {
      timer=setInterval(function(){num++;forwards()}, 2000);
   });;
      timer=setInterval(function(){num++;forwards()}, 2000);
   // sliders;
   //submenu;
   $(".submenu li").each(function(index,value){
      var $index=$(this).index();
      $(this).mouseenter(function (){
         $(".subinnerbox").eq($index).css({display:"block"});
      })
      $(this).mouseleave(function(event){
         $(".subinnerbox").eq($index).css({display:"none"});

         // setTimeout(function(){alert("ss")}, 1000)
      })

   });

     $(".subinnerbox").each(function(index,value){
      var $index=$(this).index();
      $(this).mouseenter(function (){
         $(".subinnerbox").eq($index).css({display:"block"});
      })
      $(this).mouseleave(function(event){
         $(".subinnerbox").eq($index).css({display:"none"});

         // setTimeout(function(){alert("ss")}, 1000)
      })

   });
//subcourse;
$(".subcourse").mouseenter(function(event) {
   $(this).find(".description").stop().animate({bottom:"20px"},"fast");
}).mouseleave(function(event) {
   $(this).find(".description").stop().animate({bottom:"-25px"}, "fast");
});;
//codebar
$(".codemain").mouseenter(function(event) {
   $(".appdownload").css({display:"block",opacity:0}).stop().animate({opacity:1}, "fast")
}).mouseleave(function(event) {
   $(".appdownload").stop().animate({opacity: 0},"slow", function() {
      $(this).css({display:"none"})
   });});
//scroll
$(window).scroll(function(event) {
   if ($(this).scrollTop()>800) {
      $(".gotop").css({display:"block"});
   }else {
      $(".gotop").css({display:"none"});
   }
});











});